Hello dear customers :)

We thank you for purchasing our theme. Hope our theme will be of great help for you to succeed. We appreciate your decision to read the manual before the request for our support.

Please refer to our support systems:
- Forums: https://forums.thembay.com/
- Facebook: https://www.facebook.com/thembayteam/
- Ticket System: https://tickets.thembay.com/
- Video Tutorials: https://www.youtube.com/c/thembay	
- Documentation: https://docs.thembay.com/besa/


===================

Check out our themes and you can find everything that you need. We always do the best to make our customers be satisfied with our awesome work.

Our Portfolio: https://themeforest.net/user/thembay/portfolio	
